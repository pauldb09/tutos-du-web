
<?php
if(isset($_REQUEST['nom'] , $_REQUEST['age'] , $_REQUEST['ville'])){
$nom = $_REQUEST['nom'];
$age = $_REQUEST['age'];
$ville = $_REQUEST['ville'];
echo '<p>Bonjour '.$nom.' tu as '.$age.' ans et tu vient de '.$ville.' , Bienvenue sur mon site</p>';
}else{
   echo 'aucune valeur envoyée';
}
?>