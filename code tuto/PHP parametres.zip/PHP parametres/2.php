<?php
//si il n'y a pas de parametre page
if(!isset($_GET['page'])){
   //redirection grace a la fonction header
   header('location:?page=accueil');
}
//si le paramètre existe , on le prend .
if(isset($_GET['page'])){
$page = $_GET['page'];
//si le paramètre page est égal a accueil , on affiche l'accueil
if($page == 'accueil'){
echo '<h1>Accueil</h1>
<a href="?page=autre">Aller sur la page avec un autre paramètre</a>
<p>vous etes actuellement sur l\'accueil</p>
le paramètre page a pour valeur : '.$page.' ';
}
//afichage de l\'autre page
if($page == 'autre'){
   echo '<h1>Autre Page </h1>
   <a href="?page=accueil">Aller sur la page avec un autre paramètre</a>
   <p>vous etes actuellement sur l\'autre page</p>
   le paramètre page a pour valeur : '.$page.' ';
   }
}else{
   echo 'aucun paramètre envoyé ! ';
}