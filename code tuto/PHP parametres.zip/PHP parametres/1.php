<?php
//si le paramètre existe , on le prend .
if(isset($_GET['page'])){
   $page = $_GET['page'];
   echo 'le paramètre page a pour valeur : '.$page.'';
   }else{
      echo 'aucun paramètre envoyé ! ';
   }